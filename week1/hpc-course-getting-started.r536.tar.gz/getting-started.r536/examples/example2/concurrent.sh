#!/bin/bash

# Placing all o/p on a single line to avoid inter-leaving
# Adding a random number to prove separate processes!

echo "Runnning on:" $HOSTNAME "At time:" `date` "Random number:" $RANDOM 

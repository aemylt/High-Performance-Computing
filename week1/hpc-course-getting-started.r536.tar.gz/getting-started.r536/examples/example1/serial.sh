#!/bin/bash

echo "============================="
echo "Serial Script"
echo "============================="
echo "Runnning on:" $HOSTNAME
echo "At time:" `date`
echo "In directory:" `pwd`
echo "Done."
echo "============================="

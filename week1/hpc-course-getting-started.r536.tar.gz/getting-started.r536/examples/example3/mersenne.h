
/* function prototypes */
void sgenrand(unsigned long seed);
void lsgenrand(unsigned long *seed_array);
double genrand();
